﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P03_JediGalaxy
{
    public class DoMagic : IDoMagic
    {
        public int[,] LoadMatrixWhitData(int rowCount, int columnCount)
        {
            int[,] matrix = new int[rowCount, columnCount];
            int value = 0;
            for (int i = 0; i < rowCount; i++)
            {
                for (int j = 0; j < columnCount; j++)
                {
                    matrix[i, j] = value++;
                }
            }
            return matrix;
        }

        public int[] SplitStringToArray(string inputString)
        {
            int[] result = inputString
                .Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();
            return result;
        }

        public bool CheckInsideInMatrix(ICoordinate coordinate, int[,] matrix)
        {
            return coordinate.X >= 0 && coordinate.X < matrix.GetLength(0) && coordinate.Y >= 0 && coordinate.Y < matrix.GetLength(1);
        }

        public int[,] MoveEnemyCalculate(ICoordinate coordinate, int[,] matrix)
        {
            while (coordinate.X >= 0 && coordinate.Y >= 0)
            {
                if (CheckInsideInMatrix(coordinate, matrix))
                {
                    matrix[coordinate.X, coordinate.Y] = 0;
                }
                coordinate.X--;
                coordinate.Y--;
            }
            return matrix;
        }

        public long MoveIvoCoordinate(ICoordinate ivoCoordinate, int[,] matrix, long sum)
        {
            while (ivoCoordinate.X >= 0 && ivoCoordinate.Y < matrix.GetLength(1))
            {
                if (CheckInsideInMatrix(ivoCoordinate, matrix))
                {
                    sum += matrix[ivoCoordinate.X, ivoCoordinate.Y];
                }

                ivoCoordinate.Y++;
                ivoCoordinate.X--;
            }
            return sum;
        }
    }
}
