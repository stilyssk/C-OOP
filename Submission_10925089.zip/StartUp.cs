﻿namespace P03_JediGalaxy
{
    using System;
    using System.Linq;
    public class StartUp
    {
        static void Main()
        {
            IDoMagic doMagic = new DoMagic();
            int[] dimestions = Console.ReadLine()
                .Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();
            int rowCount = dimestions[0];
            int columnCount = dimestions[1];
            var matrix = doMagic.LoadMatrixWhitData(rowCount, rowCount);

            string command = Console.ReadLine();
            long sum = 0;
            while (command != "Let the Force be with you")
            {
                int[] ivoInpuCoordinate = doMagic.SplitStringToArray(command);
                int[] evilInputCoordinate = doMagic.SplitStringToArray(Console.ReadLine());
                ICoordinate enemyCoordinate = new Coordinate(evilInputCoordinate);
                matrix = doMagic.MoveEnemyCalculate(enemyCoordinate, matrix);

                ICoordinate ivoCoordinate = new Coordinate(ivoInpuCoordinate);
                sum = doMagic.MoveIvoCoordinate(ivoCoordinate, matrix, sum);
                command = Console.ReadLine();
            }

            Console.WriteLine(sum);

        }

        //static int[,] LoadMatrixWhitData(int rowCount,int columnCount)
        //{
        //    int[,] matrix = new int[rowCount, columnCount];
        //    int value = 0;
        //    for (int i = 0; i < rowCount; i++)
        //    {
        //        for (int j = 0; j < columnCount; j++)
        //        {
        //            matrix[i, j] = value++;
        //        }
        //    }
        //    return matrix;
        //}

        //static int[] SplitStringToArray(string inputString)
        //{
        //    int[] result = inputString
        //        .Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)
        //        .Select(int.Parse)
        //        .ToArray();
        //    return result;
        //}

        //static bool CheckInsideInMatrix(ICoordinate coordinate, int[,] matrix)
        //{
        //    return coordinate.X >= 0 && coordinate.X < matrix.GetLength(0) && coordinate.Y >= 0 && coordinate.Y < matrix.GetLength(1);
        //}

        //static int[,] MoveEnemyCalculate(ICoordinate coordinate,int[,] matrix)
        //{
        //    while (coordinate.X >= 0 && coordinate.Y >= 0)
        //    {
        //        if (CheckInsideInMatrix(coordinate, matrix))
        //        {
        //            matrix[coordinate.X, coordinate.Y] = 0;
        //        }
        //        coordinate.X--;
        //        coordinate.Y--;
        //    }
        //    return matrix;
        //}
 
        //static long MoveIvoCoordinate( ICoordinate ivoCoordinate, int[,] matrix, long sum)
        //{
        //    while (ivoCoordinate.X >= 0 && ivoCoordinate.Y < matrix.GetLength(1))
        //    {
        //        if (CheckInsideInMatrix(ivoCoordinate, matrix))
        //        {
        //            sum += matrix[ivoCoordinate.X, ivoCoordinate.Y];
        //        }

        //        ivoCoordinate.Y++;
        //        ivoCoordinate.X--;
        //    }
        //    return sum;
        //}
    }
}
