﻿namespace P03_JediGalaxy
{
    public interface IDoMagic
    {
        bool CheckInsideInMatrix(ICoordinate coordinate, int[,] matrix);
        int[,] LoadMatrixWhitData(int rowCount, int columnCount);
        int[,] MoveEnemyCalculate(ICoordinate coordinate, int[,] matrix);
        long MoveIvoCoordinate(ICoordinate ivoCoordinate, int[,] matrix, long sum);
        int[] SplitStringToArray(string inputString);
    }
}