﻿namespace P01.Stream_Progress
{
    public interface IFile
    {
        int BytesSent { get; set; }
        int Length { get; set; }
    }
}