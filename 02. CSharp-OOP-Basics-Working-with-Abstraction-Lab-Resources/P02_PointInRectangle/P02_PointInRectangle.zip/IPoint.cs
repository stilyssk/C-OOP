﻿namespace P02_PointInRectangle
{
    public interface IPoint
    {
        int XCoordinate { get; set; }
        int YCoordinate { get; set; }
    }
}