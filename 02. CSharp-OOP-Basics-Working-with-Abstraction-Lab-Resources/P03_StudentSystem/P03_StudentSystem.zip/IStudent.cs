﻿namespace P03_StudentSystem
{
    public interface IStudent
    {
        int Age { get; set; }
        double Grade { get; set; }
        string Name { get; set; }
    }
}