﻿using System;

namespace CreateAttribute
{
    
    [Author("Ventsi")]
    class StartUp
    {
        [Author("Gosho")]
        static void Main(string[] args)
        {
        }
    }
}
