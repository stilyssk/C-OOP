﻿using System.Collections.Generic;

namespace MortalEngines.Factory
{
    public interface IFactoryClass
    {
        List<string> CreateBaseMashineTargetList();
    }
}