﻿using System;

namespace AnimalCentre
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //TODO Run your application from here
        }
    }
}
