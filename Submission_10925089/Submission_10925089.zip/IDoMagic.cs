﻿namespace P03_JediGalaxy
{
    public interface IDoMagic
    {
        string ToString();
    }
}