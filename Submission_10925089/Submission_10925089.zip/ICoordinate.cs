﻿namespace P03_JediGalaxy
{
    public interface ICoordinate
    {
        int X { get; set; }
        int Y { get; set; }
    }
}