﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_GreedyTimes
{
    public class Gold
    {
        private List<int> quantity;
        public Gold()
        {

        }
    }
}
