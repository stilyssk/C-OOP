﻿namespace TrafficLights
{
    public interface ILights
    {
        string Collor { get; set; }
    }
}