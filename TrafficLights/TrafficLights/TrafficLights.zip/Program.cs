﻿using System;
using System.Collections.Generic;
using System.Linq;
using TrafficLights.Classes;

namespace TrafficLights
{
    public class Program
    {
        static void Main(string[] args)
        {

            TrafficLight newTrafficLight = new TrafficLight();
            string[] inputLight = Console.ReadLine()
                .Split(new[] { ' ' })
                .ToArray();
            int repeatTime = int.Parse(Console.ReadLine());
            List<ILights> test = new List<ILights>();

            for (int i = 0; i < inputLight.Length; i++)
            {
                newTrafficLight.AddLight(inputLight[i]);
            }

            for (int i = 0; i < repeatTime; i++)
            {
                newTrafficLight.rotateLight();
                Console.WriteLine(newTrafficLight.Print());
            }

            //for (int i = 0; i < inputLight.Length; i++)
            //{
            //    ILights newLight = new ILights(inputLight[i]);
            //    test.Add(newLight);
            //}

            //for (int i = 0; i < repeatTime; i++)
            //{
            //    var firstElement = test[0];
            //    var lastElement = test[test.Count - 1];
            //    test.Insert(0, lastElement);
            //    test.RemoveAt(test.Count - 1);
            //    foreach (var item in test)
            //    {
            //        Console.Write(item.Collor);
            //    }
            //    Console.WriteLine();
            //}
 
        }
    }
}
