﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrafficLights
{
    public class Lights : ILights
    {
        private string collor;

        public Lights(string collor)
        {
            Collor = collor;
        }

        public string Collor { get => collor; set => collor = value; }


    }
}
