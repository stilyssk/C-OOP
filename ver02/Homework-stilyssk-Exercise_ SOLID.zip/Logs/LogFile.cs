﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06._CSharp_OOP_SOLID_Exercise
{
    public class LogFile : ILogger
    {
        public void Error(string inputDatetime, string inputMessage)
        {
            throw new NotImplementedException();
        }

        public void Info(string inputDatetime, string inputMessage)
        {
            throw new NotImplementedException();
        }
    }
}
