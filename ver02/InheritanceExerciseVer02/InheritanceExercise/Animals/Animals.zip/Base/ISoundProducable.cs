﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals.Base
{
    public interface ISoundProducable
    {
        string ProduceSound();
    }
}
