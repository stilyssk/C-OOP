﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Factorys.BaseType
{
    public class Food
    {
        public int happines { get; set; }
    }
}
