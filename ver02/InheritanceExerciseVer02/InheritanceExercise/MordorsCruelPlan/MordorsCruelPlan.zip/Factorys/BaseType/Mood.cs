﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Factorys.BaseType
{
    public class Mood
    {
        public string mood { get; set; }

        public override string ToString()
        {
            return mood;
        }
    }
}
