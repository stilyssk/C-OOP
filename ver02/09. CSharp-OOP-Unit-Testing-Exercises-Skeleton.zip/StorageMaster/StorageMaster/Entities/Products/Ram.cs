﻿namespace StorageMaster.Entities.Products
{
	public class Ram : Product
	{
		public Ram(double price)
			: base(price, 0.1)
		{
		}
	}
}