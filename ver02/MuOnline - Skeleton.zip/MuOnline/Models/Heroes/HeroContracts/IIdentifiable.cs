﻿namespace MuOnline.Models.Heroes.HeroContracts
{
    public interface IIdentifiable
    {
        string Username { get; }
    }
}
