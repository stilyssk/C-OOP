﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MuOnline.Models.Heroes
{
    public class Elf
    {
        private const int strength = 15;
        private const int agility = 30;
        private const int stamina = 60;
        private const int energy = 80;
    }
}
