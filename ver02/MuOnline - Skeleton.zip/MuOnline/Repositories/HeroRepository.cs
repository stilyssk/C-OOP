﻿namespace MuOnline.Repositories
{
    public class HeroRepository
    {
        
    }
}
