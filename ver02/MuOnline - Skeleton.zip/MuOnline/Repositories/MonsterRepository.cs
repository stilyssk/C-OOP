﻿namespace MuOnline.Repositories
{
    public class MonsterRepository
    {
       
    }
}
