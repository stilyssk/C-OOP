﻿namespace MuOnline.Core.Factories
{
    public class HeroFactory
    {
    }
}
