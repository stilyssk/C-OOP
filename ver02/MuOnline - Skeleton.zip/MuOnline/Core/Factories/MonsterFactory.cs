﻿namespace MuOnline.Core.Factories
{
    public class MonsterFactory
    {
    }
}
