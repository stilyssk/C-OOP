﻿namespace MuOnline.Core.Commands
{
    public class AddItemToHero
    {
    }
}
