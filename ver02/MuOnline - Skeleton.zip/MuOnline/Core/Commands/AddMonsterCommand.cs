﻿namespace MuOnline.Core.Commands
{
    public class AddMonsterCommand 
    {
        
    }
}
