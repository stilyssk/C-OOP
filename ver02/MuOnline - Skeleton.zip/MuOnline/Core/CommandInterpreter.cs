﻿namespace MuOnline.Core
{
    using System;

    public class CommandInterpreter
    {
        private const string Suffix = "command";
        private readonly IServiceProvider serviceProvider;
    }
}
