﻿namespace FoodShortage.Interfaces
{
    public interface IPet
    {
        string Date { get; set; }
        string Name { get; set; }
    }
}