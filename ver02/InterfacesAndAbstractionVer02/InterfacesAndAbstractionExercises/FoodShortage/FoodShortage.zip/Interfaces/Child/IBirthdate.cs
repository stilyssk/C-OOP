﻿namespace FoodShortage.Interfaces.Child
{
    public interface IBirthdate
    {
        string Date { get; set; }
    }
}