﻿namespace FoodShortage.Interfaces.Child
{
    public interface IRebel
    {
        string Group { get; set; }
    }
}