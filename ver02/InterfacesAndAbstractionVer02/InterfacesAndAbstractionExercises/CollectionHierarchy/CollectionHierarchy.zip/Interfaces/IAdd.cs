﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.Interfaces
{
    public interface IAdd
    {
       int Add(string item);

    }
}
