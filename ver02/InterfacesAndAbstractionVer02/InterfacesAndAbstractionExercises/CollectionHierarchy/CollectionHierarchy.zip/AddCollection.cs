﻿
using CollectionHierarchy.Interfaces;
using System.Collections.Generic;

namespace CollectionHierarchy
{
    public class AddCollection : AddClass
    {

    }
}
