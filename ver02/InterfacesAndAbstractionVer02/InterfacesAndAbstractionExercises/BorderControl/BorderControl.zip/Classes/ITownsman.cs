﻿namespace BorderControl.Classes
{
    public interface ITownsman
    {
        string ID { get; set; }
    }
}