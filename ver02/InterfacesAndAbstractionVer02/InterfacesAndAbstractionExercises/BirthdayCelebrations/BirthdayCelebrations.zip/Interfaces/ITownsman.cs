﻿namespace BirthdayCelebrations.Interfaces
{
    public interface ITownsman
    {
        string ID { get; set; }
    }
}