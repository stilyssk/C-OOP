﻿namespace BirthdayCelebrations.Interfaces.Child
{
    public interface IBirthdate
    {
        string Date { get; set; }
    }
}