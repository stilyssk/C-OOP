﻿namespace MilitaryElite.Interfaces.Silders.Privates.SpecialisedSoldiers
{
    public interface ICorp
    {
        string CorpName { get; set; }
    }
}
