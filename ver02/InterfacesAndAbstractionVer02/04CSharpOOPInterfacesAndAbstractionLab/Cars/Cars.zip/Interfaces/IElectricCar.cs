﻿namespace Cars.Interfaces
{
    public interface IElectricCar
    {
        int BatteryCount { get; set; }
    }
}