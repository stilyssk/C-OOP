﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes.Interfaces
{
    public interface IDrawable
    {
        void Draw();
    }
}
