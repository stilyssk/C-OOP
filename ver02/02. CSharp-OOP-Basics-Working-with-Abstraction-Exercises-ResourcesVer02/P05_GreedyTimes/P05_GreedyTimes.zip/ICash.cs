﻿namespace P05_GreedyTimes
{
    public interface ICash
    {
        long Count { get; set; }
        string Name { get; set; }
    }
}