﻿namespace P02_CarsSalesman
{
    public interface ICar
    {
        string ToString();
    }
}