﻿namespace P02_CarsSalesman
{
    public interface IEngine
    {
        string Model { get; set; }

         string ToString();
    }
}