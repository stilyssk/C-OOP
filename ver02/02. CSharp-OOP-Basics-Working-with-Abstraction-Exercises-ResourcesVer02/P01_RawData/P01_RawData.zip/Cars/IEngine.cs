﻿namespace P01_RawData.Cars
{
    public interface IEngine
    {
        int EnginePower { get; set; }
        int EngineSpeed { get; set; }
    }
}