﻿

namespace P01_RawData
{
    using P01_RawData.Cars;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Car
    {
        private IEngine engine;
        private ICargo cargo;
        private ITire[] tires;
        public Car(
            string model,
            IEngine engine,
            ICargo cargo,
            ITire[] tires
            )
        {
            this.model = model;
            this.Engine = engine;
            this.Cargo = cargo;
            this.Tires = tires;
        }

        //public Car(
        //    string model,
        //    IEngine engine,
        //    ICargo cargo,
        //    ITire tire1,
        //    ITire tire2,
        //    ITire tire3,
        //    ITire tire4)
        //{
        //    this.model = model;
        //    this.Engine = engine;
        //    this.Cargo = cargo;
        //    //ITire tire1 = new Tire(tire1Pressure, tire1Age);
        //    //ITire tire2 = new Tire(tire2Pressure, tire2Age);
        //    //ITire tire3 = new Tire(tire3Pressure, tire3Age);
        //    //ITire tire4 = new Tire(tire4Pressure, tire4Age);
        //    this.Tires = new ITire[4]
        //    {
        //        tire1,
        //        tire2,
        //        tire3,
        //        tire4
        //    };
        //    //this.tires = new KeyValuePair<double, int>[] { KeyValuePair.Create(tire1Pressure, tire1Age), KeyValuePair.Create(tire2Pressure, tire2Age), KeyValuePair.Create(tire3Pressure, tire3age), KeyValuePair.Create(tire4Pressure, tire4age) };
        //}

        //public Car(
        //    string model,
        //    int engineSpeed,
        //    int enginePower,
        //    int cargoWeight,
        //    string cargoType,
        //    double tire1Pressure,
        //    int tire1Age,
        //    double tire2Pressure,
        //    int tire2Age,
        //    double tire3Pressure,
        //    int tire3Age,
        //    double tire4Pressure,
        //    int tire4Age)
        //{
        //    this.model = model;
        //    this.Engine = new Engine(engineSpeed, enginePower);
        //    this.Cargo = new Cargo(cargoWeight, cargoType);
        //    ITire tire1 = new Tire(tire1Pressure, tire1Age);
        //    ITire tire2 = new Tire(tire2Pressure, tire2Age);
        //    ITire tire3 = new Tire(tire3Pressure, tire3Age);
        //    ITire tire4 = new Tire(tire4Pressure, tire4Age);
        //    this.Tires = new ITire[4]
        //    {
        //        tire1,
        //        tire2,
        //        tire3,
        //        tire4
        //    };
        //    //this.tires = new KeyValuePair<double, int>[] { KeyValuePair.Create(tire1Pressure, tire1Age), KeyValuePair.Create(tire2Pressure, tire2Age), KeyValuePair.Create(tire3Pressure, tire3age), KeyValuePair.Create(tire4Pressure, tire4age) };
        //}
        public string model;


        //public KeyValuePair<double, int>[] tires;

        public IEngine Engine { get => engine; set => engine = value; }
        public ICargo Cargo { get => cargo; set => cargo = value; }
        public ITire[] Tires { get => tires; set => tires = value; }
    }
}
