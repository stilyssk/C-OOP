﻿namespace P01_RawData.Cars
{
    public interface ICargo
    {
        string CargoType { get; set; }
        int CargoWeight { get; set; }
    }
}