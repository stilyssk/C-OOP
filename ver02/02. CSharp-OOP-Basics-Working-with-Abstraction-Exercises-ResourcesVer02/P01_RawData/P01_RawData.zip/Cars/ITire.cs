﻿namespace P01_RawData.Cars
{
    public interface ITire
    {
        int Age { get; set; }
        double Pressure { get; set; }
    }
}