﻿namespace Telephony
{
    public interface IBrowsing
    {
        string SiteUrl { get; set; }

        string PrintBrowsing();
    }
}
