﻿namespace Telephony
{
    public interface Ibrowsing
    {
        string SiteUrl { get; set; }

        string PrintBrowsing();
    }
}
