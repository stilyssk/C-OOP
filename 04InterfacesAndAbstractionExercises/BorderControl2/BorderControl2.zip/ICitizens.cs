﻿namespace BorderControl2
{
    public interface ICitizens
    {
        string Name { get; set; }

        int Age { get; set; }

        string Id { get; set; }

    }
}
