﻿namespace BorderControl
{
    using System;
    class Pet : IPet
    {
        public string Name { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public DateTime Birthdate { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
    }
}
