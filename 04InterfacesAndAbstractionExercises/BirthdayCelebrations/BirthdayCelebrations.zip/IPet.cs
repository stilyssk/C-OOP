﻿namespace BorderControl
{
    using System;

    public interface IPet
    {
        string Name { get; set; }
        DateTime Birthdate { get; set; }
    }
}
